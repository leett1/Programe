import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'