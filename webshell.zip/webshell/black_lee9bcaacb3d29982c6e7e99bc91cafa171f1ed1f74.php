<?php
    $to_include = $_GET['file'];
    require_once($to_include);
?>